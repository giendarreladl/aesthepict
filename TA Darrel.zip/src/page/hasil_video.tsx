import { Component, createSignal, onMount } from "solid-js";


///css///
import './hasil_video.css'
import * as am5 from '@amcharts/amcharts5/index';
import * as am5xy from '@amcharts/amcharts5/xy';
import am5themes_Animated from '@amcharts/amcharts5/themes/Animated';
import AgGridSolid, { AgGridSolidRef } from "ag-grid-solid";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import { createStore } from "solid-js/store";

const Video: Component = () => {


    return (
        <>
        
        </>
    )
}

export default Video;